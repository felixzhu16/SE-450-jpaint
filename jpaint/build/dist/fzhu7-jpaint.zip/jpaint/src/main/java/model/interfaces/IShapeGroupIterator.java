package model.interfaces;

public interface IShapeGroupIterator {
    boolean hasNext();
    IShape getNext();
}
