package model;

import model.interfaces.IShape;

import java.awt.*;

public class DrawDash implements IShape {
    Point start, end;
    IShape shape;
    public DrawDash(IShape shape){
        this.start = shape.getFixedStart();
        this.end = shape.getFixedEnd();
        this.shape = shape;
    }
    @Override
    public void draw(Graphics2D g) {
        shape.draw(g);

    }

    @Override
    public Point getFixedStart() {
        return start;
    }

    @Override
    public Point getFixedEnd() {
        return end;
    }

    @Override
    public void modXYCoords(double x, double y) {

    }

    @Override
    public ShapeInfo getShapeInfo() {
        return shape.getShapeInfo();
    }
}
