package model;

public enum Undo {
    OK,
    CANCEL;
}
