package model.interfaces;

import model.*;

import java.awt.*;
import java.util.ArrayList;

public interface IShape {
    void draw(Graphics2D g);
}
