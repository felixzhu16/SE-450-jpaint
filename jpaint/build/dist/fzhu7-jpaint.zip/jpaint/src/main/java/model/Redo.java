package model;

public enum Redo {
    OK,
    CANCEL;
}
