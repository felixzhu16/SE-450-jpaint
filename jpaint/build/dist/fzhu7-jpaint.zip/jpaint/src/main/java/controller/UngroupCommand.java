package controller;

public class UngroupCommand implements ICommand, IUndoable{



    @Override
    public void run() {

    }

    @Override
    public void undo() {

    }

    @Override
    public void redo() {

    }
}
