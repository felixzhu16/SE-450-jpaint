package model;

import model.interfaces.IShape;

import java.awt.*;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class ShapeGroup implements IShape {
    private ArrayList<IShape> groupedShapes;
    private IShape group;

    public ShapeGroup(){
        this.groupedShapes = new ArrayList<IShape>();

    }

    public void group(ArrayList<IShape> selected){
        if(selected != null){
            for(IShape s : selected){
                groupedShapes.add(s);
            }
        }
    }

    public ArrayList<IShape> unGroup(){
        ArrayList<IShape> originalShapes = new ArrayList<IShape>();
        for(IShape s : groupedShapes){
            originalShapes.add(s);
        }
        return originalShapes;
    }

    @Override
    public void draw(Graphics2D g) {
        for(IShape s : groupedShapes){
            s.draw(g);
        }
    }

    @Override
    public Point getFixedStart() {
        return null;
    }

    @Override
    public Point getFixedEnd() {
        return null;
    }

    @Override
    public void setFixedStart(Point x) {

    }

    @Override
    public void setFixedEnd(Point x) {

    }

    @Override
    public void modXYCoords(double x, double y) {

    }

    @Override
    public ShapeInfo getShapeInfo() {
        return null;
    }

    @Override
    public void setShapeInfo(ShapeInfo shapeinfo) {

    }
}
