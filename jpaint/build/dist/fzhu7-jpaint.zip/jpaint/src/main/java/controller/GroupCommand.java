package controller;

import model.ShapeGroup;
import model.ShapeList;
import model.interfaces.IShape;

public class GroupCommand implements ICommand, IUndoable{
    private ShapeGroup shapeGroup;
    private ShapeList shapeList;

    public GroupCommand(ShapeList shapelist, ShapeGroup shapeGroup){
        this.shapeList = shapelist;
        this.shapeGroup = shapeGroup;
    }

    @Override
    public void run() {
        if(!shapeList.getSelectList().isEmpty()){
            shapeGroup.group(shapeList.getSelectList());
        }
        //Removing all selected shapes from the shapelist
        for(IShape shape: shapeList.getSelectList()){
            shapeList.getCurrList().remove(shape);
        }

        shapeList.getSelectList().add(shapeGroup);
        CommandHistory.add(this);
    }

    @Override
    public void undo() {

    }

    @Override
    public void redo() {

    }
}
